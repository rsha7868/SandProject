public class SandRunner
{
   public static void main(String [] args)
   {
      SandLab app = new SandLab(20,20); 
      app.run();
   }
  
}